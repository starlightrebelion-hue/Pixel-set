import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Clapperboard, n as Pause, r as Megaphone, t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { n as previewPathPrefix } from "./router-D6rD0baG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-uUXY21Le.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SCENES = [
	"La traición",
	"El reencuentro",
	"La carta",
	"Bajo la lluvia",
	"El silencio",
	"Última toma"
];
var CREW = [
	{
		id: "director",
		name: "Rey",
		role: "Dirección",
		homeX: .22,
		homeY: .74,
		job: "Quiero emoción, no sólo planos lindos."
	},
	{
		id: "guion",
		name: "Sol",
		role: "Guion",
		homeX: .34,
		homeY: .86,
		job: "Esta escena necesita un objetivo claro y un giro."
	},
	{
		id: "camara",
		name: "Nico",
		role: "Cámara",
		homeX: .46,
		homeY: .66,
		job: "Marco el plano. Necesito luz y la marca de los actores."
	},
	{
		id: "luz",
		name: "Vera",
		role: "Luces",
		homeX: .7,
		homeY: .64,
		job: "Estoy armando el clima. No me muevan los prácticos."
	},
	{
		id: "sonido",
		name: "Teo",
		role: "Sonido",
		homeX: .76,
		homeY: .8,
		job: "Silencio en el set. Estoy cazando un zumbido."
	},
	{
		id: "montaje",
		name: "Lila",
		role: "Montaje",
		homeX: .28,
		homeY: .7,
		job: "Sin continuidad no hay relato. Reviso el orden de las tomas."
	},
	{
		id: "produccion",
		name: "Marcos",
		role: "Producción",
		homeX: .56,
		homeY: .88,
		job: "Tiempo y presupuesto. Cuidado con los retrasos."
	},
	{
		id: "actores",
		name: "Nina",
		role: "Actuación",
		homeX: .52,
		homeY: .76,
		job: "Estoy buscando qué quiere el personaje en esta toma."
	}
];
var BOUNDS = {
	minX: .14,
	maxX: .84,
	minY: .58,
	maxY: .93
};
var FLOOR = [
	[.24, .7],
	[.36, .78],
	[.48, .72],
	[.6, .8],
	[.7, .7],
	[.32, .88],
	[.66, .88],
	[.42, .84]
];
var COMPLAINTS = {
	guion: "El conflicto no avanza. ¿Cuál es el objetivo de la escena?",
	camara: "Ese encuadre no acompaña el punto de vista del personaje.",
	luz: "La luz está plana. Quiero clima, no un catálogo.",
	sonido: "Hay ruido. No dirijo una escena que no se escucha.",
	montaje: "Cortaste antes del gesto. Se pierde la emoción.",
	produccion: "Se nos va el día. Organizá el cambio de set.",
	actores: "Más intención. El personaje quiere algo: mostralo."
};
var ISSUES = {
	guion: "Se me cayó una página y cambió el orden de las escenas.",
	camara: "Se trabó la tarjeta. Perdimos la última toma.",
	luz: "Se fundió una luz y se fue el clima de la escena.",
	sonido: "Entró ruido de tráfico. Hay que repetir.",
	montaje: "Las tomas no cierran: un objeto cambió de lugar.",
	produccion: "Se retrasó el permiso de esta locación.",
	actores: "Perdí el hilo emocional del personaje."
};
var ANGRY_REPLIES = [
	"¡Está bien! Lo corrijo ya.",
	"No me apures, lo estoy resolviendo.",
	"¡No es tan fácil como parece!",
	"Uf… está bien. Vuelvo a trabajar."
];
var FIXED_REPLIES = [
	"Listo, ya está resuelto.",
	"Volví al trabajo.",
	"Quedó corregido.",
	"Sigo con esto."
];
var CHATS = [
	{
		a: "guion",
		b: "camara",
		line: "El plano tiene que revelar el secreto justo acá.",
		reply: "Entonces lo dejo en el eje hasta el gesto."
	},
	{
		a: "camara",
		b: "luz",
		line: "Necesito más contraste del lado izquierdo.",
		reply: "Te bajo la contra y subo la key."
	},
	{
		a: "sonido",
		b: "produccion",
		line: "Para esta toma necesito silencio absoluto.",
		reply: "Cierro el set. Nadie entra."
	},
	{
		a: "montaje",
		b: "guion",
		line: "Si sacamos esta réplica, el arco queda más claro.",
		reply: "Dale, pero no perdamos el objetivo."
	},
	{
		a: "actores",
		b: "director",
		line: "¿Mi personaje ya sabe que la traicionaron?",
		reply: "Todavía no. Duda, no llanto."
	},
	{
		a: "produccion",
		b: "director",
		line: "Si repetimos mucho, perdemos la luz del ventanal.",
		reply: "Entonces esta es la buena. Concentración."
	},
	{
		a: "luz",
		b: "camara",
		line: "La key está lista. No me muevan el trípode.",
		reply: "No lo toco. Sólo ajusto el foco."
	},
	{
		a: "director",
		b: "actores",
		line: "Menos explicación y más deseo.",
		reply: "Lo busco desde el cuerpo, no desde el texto."
	},
	{
		a: "sonido",
		b: "luz",
		line: "Ese dimmer zumba. ¿Lo podés cambiar?",
		reply: "Lo saco y paso a la otra línea."
	},
	{
		a: "montaje",
		b: "camara",
		line: "Cuidá el eje: en la toma anterior miraba a la izquierda.",
		reply: "Anotado. Misma altura de ojos."
	}
];
function stateLabel(state, moving) {
	if (state === "work" && moving) return "Camina";
	if (state === "work") return "Trabaja";
	if (state === "angry") return "Enojado";
	if (state === "sleep") return "Duerme";
	return "Habla";
}
var SPEED = .16;
var BUBBLE_LIFE = 3.4;
function clamp(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
function dist(x1, y1, x2, y2) {
	return Math.hypot(x2 - x1, y2 - y1);
}
function pick(items) {
	return items[Math.floor(Math.random() * items.length)];
}
function clampPoint(x, y) {
	return [clamp(x, BOUNDS.minX, BOUNDS.maxX), clamp(y, BOUNDS.minY, BOUNDS.maxY)];
}
function createSim(onLog) {
	let logId = 1;
	let take = 1;
	let sceneIndex = 0;
	let stress = 12;
	let quality = 8;
	let paused = false;
	let shake = 0;
	let time = 0;
	let chatCooldown = 2.2;
	let pending = null;
	const particles = [];
	const people = CREW.map((c) => ({
		id: c.id,
		name: c.name,
		role: c.role,
		job: c.job,
		x: c.homeX,
		y: c.homeY,
		tx: c.homeX,
		ty: c.homeY,
		homeX: c.homeX,
		homeY: c.homeY,
		facing: 1,
		state: "work",
		stateTimer: 0,
		decision: 1 + Math.random() * 2,
		boredom: Math.random() * 3,
		cooldown: 4,
		napping: false,
		partner: null,
		bubble: null,
		ring: 0
	}));
	const byId = (id) => people.find((p) => p.id === id);
	function burst(kind, x, y, n) {
		for (let i = 0; i < n; i++) particles.push({
			kind,
			x,
			y,
			vx: (Math.random() - .5) * .08,
			vy: kind === "confetti" ? -.05 - Math.random() * .08 : -.03 - Math.random() * .04,
			life: .8 + Math.random() * .8,
			max: 1.4,
			char: kind === "z" ? pick([
				"z",
				"z",
				"Z"
			]) : ""
		});
		if (particles.length > 90) particles.splice(0, particles.length - 90);
	}
	function say(p, text, kind) {
		const active = people.filter((q) => q.bubble);
		if (active.length >= 2) {
			active.sort((a, b) => (a.bubble?.life ?? 0) - (b.bubble?.life ?? 0));
			active[0].bubble = null;
		}
		p.bubble = {
			text,
			life: BUBBLE_LIFE,
			kind
		};
		onLog({
			id: logId++,
			who: p.name,
			text,
			kind
		});
		if (kind === "angry") shake = Math.max(shake, .7);
		if (kind === "dir") shake = Math.max(shake, .45);
	}
	function cancelChat() {
		if (!pending) return;
		const a = byId(pending.a);
		const b = byId(pending.b);
		if (a.partner === b.id) a.partner = null;
		if (b.partner === a.id) b.partner = null;
		pending = null;
	}
	function release(p) {
		p.state = "work";
		p.partner = null;
		p.napping = false;
		p.tx = p.homeX;
		p.ty = p.homeY;
		p.decision = 1.5 + Math.random() * 2;
	}
	function scold(target, reason) {
		if (target.id === "director") return;
		const director = byId("director");
		if (pending && (pending.a === target.id || pending.b === target.id)) cancelChat();
		target.napping = false;
		target.state = "angry";
		target.stateTimer = 2.8;
		target.partner = "director";
		target.boredom = 0;
		target.cooldown = 14;
		target.facing = director.x < target.x ? -1 : 1;
		director.state = "angry";
		director.stateTimer = 1.5;
		director.partner = target.id;
		director.facing = target.x < director.x ? -1 : 1;
		stress = clamp(stress + (reason === "sleep" ? 10 : 16), 0, 100);
		shake = Math.max(shake, .9);
		if (reason === "sleep") {
			say(director, `¡${target.name}! Esto no es una siesta. A trabajar.`, "dir");
			say(target, pick([
				"¡Ya voy!",
				"Perdón. Me quedé.",
				"Está bien, ya estoy."
			]), "angry");
		} else {
			say(director, `¡${target.name}! ${COMPLAINTS[target.id]}`, "dir");
			say(target, pick(ANGRY_REPLIES), "angry");
		}
	}
	function tryChat() {
		if (people.filter((p) => p.state === "work" && !p.partner).length < 2) return false;
		const options = CHATS.filter((c) => {
			const a = byId(c.a);
			const b = byId(c.b);
			return a.state === "work" && b.state === "work" && !a.partner && !b.partner;
		});
		if (!options.length) return false;
		const chat = pick(options);
		const a = byId(chat.a);
		const b = byId(chat.b);
		const mx = clamp((a.x + b.x) / 2, BOUNDS.minX, BOUNDS.maxX);
		const my = clamp((a.y + b.y) / 2, BOUNDS.minY, BOUNDS.maxY);
		a.tx = clamp(mx - .035, BOUNDS.minX, BOUNDS.maxX);
		a.ty = my;
		b.tx = clamp(mx + .035, BOUNDS.minX, BOUNDS.maxX);
		b.ty = my;
		a.partner = b.id;
		b.partner = a.id;
		pending = {
			a: a.id,
			b: b.id,
			line: chat.line,
			reply: chat.reply,
			said: false,
			age: 0
		};
		return true;
	}
	function wander(p) {
		if (p.partner) return;
		if (Math.random() < .55) {
			const [x, y] = clampPoint(p.homeX + (Math.random() - .5) * .08, p.homeY + (Math.random() - .5) * .06);
			p.tx = x;
			p.ty = y;
		} else {
			const [x, y] = pick(FLOOR);
			p.tx = x;
			p.ty = y;
		}
		p.decision = 2.4 + Math.random() * 3.2;
	}
	function finishTake(ok) {
		const director = byId("director");
		const producer = byId("produccion");
		if (ok) {
			say(director, "¡Corte! Esa queda. Impriman.", "dir");
			say(producer, `Toma ${take} enlatada. Pasamos a la siguiente.`, "ok");
			burst("confetti", .5, .7, 18);
			take += 1;
			sceneIndex = (sceneIndex + 1) % SCENES.length;
			quality = 0;
			stress = clamp(stress - 28, 0, 100);
			shake = Math.max(shake, .6);
		} else {
			say(director, "¡Corten! Esta toma no sirve. Otra vez, desde el principio.", "dir");
			quality = clamp(quality - 35, 0, 100);
			stress = 38;
			shake = 1.2;
			for (const p of people) {
				if (p.id === "director") continue;
				p.state = "angry";
				p.stateTimer = 1.8;
				p.napping = false;
				p.boredom = 0;
			}
		}
	}
	function moodText() {
		if (paused) return "Pausa. El set respira.";
		if (stress > 78) return "El set está al límite.";
		if (people.some((p) => p.state === "sleep")) return "Alguien se está durmiendo en el set.";
		if (people.some((p) => p.state === "angry")) return "Tensión entre departamentos.";
		if (quality > 82) return "Esta toma está por cerrar.";
		return "Rodando. Los departamentos trabajan.";
	}
	function step(dt) {
		time += dt;
		shake = Math.max(0, shake - dt * 1.4);
		chatCooldown -= dt;
		for (const p of people) {
			if (p.bubble) {
				p.bubble.life -= dt;
				if (p.bubble.life <= 0) p.bubble = null;
			}
			p.ring = Math.max(0, p.ring - dt);
			p.cooldown = Math.max(0, p.cooldown - dt);
			if (p.state === "angry" || p.state === "talk" || p.state === "sleep") {
				p.stateTimer -= dt;
				if (p.stateTimer <= 0) {
					if (p.state === "angry" && p.id !== "director") {
						say(p, pick(FIXED_REPLIES), "ok");
						stress = clamp(stress - 6, 0, 100);
					}
					if (p.state === "sleep") {
						say(p, "Uy. Me quedé. Sigo.", "ok");
						p.cooldown = 10;
					}
					release(p);
				}
			} else if (!paused && p.state === "work") {
				p.decision -= dt;
				const atHome = dist(p.x, p.y, p.homeX, p.homeY) < .05;
				if (atHome && p.id !== "director") p.boredom += dt;
				else p.boredom = Math.max(0, p.boredom - dt * .5);
				if (p.id !== "director" && atHome && p.cooldown <= 0 && !p.partner && p.boredom > 9 && Math.random() < dt * .35) {
					p.state = "sleep";
					p.stateTimer = 7 + Math.random() * 4;
					p.napping = true;
					p.boredom = 0;
					p.tx = p.x;
					p.ty = p.y;
				} else if (p.decision <= 0 && !p.partner) wander(p);
			}
			if (p.state === "sleep" && Math.random() < dt * 1.6) burst("z", p.x, p.y - .1, 1);
			if (p.state === "angry" && Math.random() < dt * 2.2) burst("steam", p.x, p.y - .12, 1);
			if (p.state === "work" || p.state === "talk" && false || p.id === "director" && p.state === "work") {
				const dx = p.tx - p.x;
				const dy = p.ty - p.y;
				const d = Math.hypot(dx, dy);
				if (d > .008) {
					const stepDist = Math.min(d, SPEED * dt);
					p.x += dx / d * stepDist;
					p.y += dy / d * stepDist;
					if (dx < -.004) p.facing = -1;
					else if (dx > .004) p.facing = 1;
				}
			}
		}
		for (let i = 0; i < people.length; i++) for (let j = i + 1; j < people.length; j++) {
			const a = people[i];
			const b = people[j];
			const dx = a.x - b.x;
			const dy = a.y - b.y;
			const d = Math.hypot(dx, dy) || 1e-4;
			if (d < .04) {
				const push = (.04 - d) / d * .35;
				a.x += dx * push;
				a.y += dy * push;
				b.x -= dx * push;
				b.y -= dy * push;
			}
		}
		for (const p of people) {
			const [x, y] = clampPoint(p.x, p.y);
			p.x = x;
			p.y = y;
		}
		if (!paused) {
			const director = byId("director");
			const sleeper = people.find((p) => p.state === "sleep" && p.napping);
			if (sleeper && director.state === "work") {
				if (pending && (pending.a === "director" || pending.b === "director" || pending.a === sleeper.id || pending.b === sleeper.id)) cancelChat();
				director.partner = null;
				director.tx = sleeper.x;
				director.ty = clamp(sleeper.y - .03, BOUNDS.minY, BOUNDS.maxY);
				if (dist(director.x, director.y, sleeper.x, sleeper.y) < .08) scold(sleeper, "sleep");
			}
			if (pending) {
				pending.age += dt;
				const a = byId(pending.a);
				const b = byId(pending.b);
				const ready = dist(a.x, a.y, a.tx, a.ty) < .03 && dist(b.x, b.y, b.tx, b.ty) < .03;
				if (!pending.said && (ready || pending.age > 7)) {
					pending.said = true;
					a.state = "talk";
					b.state = "talk";
					a.stateTimer = 2.6;
					b.stateTimer = 2.6;
					a.tx = a.x;
					a.ty = a.y;
					b.tx = b.x;
					b.ty = b.y;
					say(a, pending.line, a.id === "director" ? "dir" : "ok");
					say(b, pending.reply, b.id === "director" ? "dir" : "ok");
					pending = null;
					chatCooldown = 5.5;
				}
			} else if (chatCooldown <= 0) {
				if (!tryChat()) chatCooldown = 1.6;
			}
			let working = 0;
			let sleeping = 0;
			let angry = 0;
			for (const p of people) if (p.state === "sleep") sleeping += 1;
			else if (p.state === "angry") angry += 1;
			else if (p.state === "work" || p.state === "talk") working += 1;
			quality = clamp(quality + (working * .55 - sleeping * 1.3 - angry * .35) * dt, 0, 100);
			stress = clamp(stress + (sleeping * .85 + angry * .35 - (sleeping + angry === 0 ? .22 : 0)) * dt, 0, 100);
			if (quality >= 100) finishTake(true);
			else if (stress >= 100) finishTake(false);
		}
		for (const particle of particles) {
			particle.life -= dt;
			particle.x += particle.vx * dt;
			particle.y += particle.vy * dt;
		}
		for (let i = particles.length - 1; i >= 0; i--) if (particles[i].life <= 0) particles.splice(i, 1);
	}
	function accion() {
		paused = false;
		stress = clamp(stress - 10, 0, 100);
		say(byId("director"), "¡Acción! Todos a sus puestos.", "dir");
		for (const p of people) {
			p.boredom = 0;
			p.cooldown = Math.max(p.cooldown, 6);
			if (p.state === "sleep") {
				p.napping = false;
				release(p);
				say(p, "¡Estoy!", "ok");
			}
		}
	}
	function scoldRandom() {
		const pool = people.filter((p) => p.id !== "director");
		const sleepers = pool.filter((p) => p.state === "sleep");
		const target = pick(sleepers.length ? sleepers : pool);
		const director = byId("director");
		director.x = clamp(target.x - .06, BOUNDS.minX, BOUNDS.maxX);
		director.y = target.y;
		scold(target, target.state === "sleep" ? "sleep" : "work");
	}
	function chaos() {
		const target = pick(people.filter((p) => p.id !== "director"));
		if (pending && (pending.a === target.id || pending.b === target.id)) cancelChat();
		target.state = "angry";
		target.stateTimer = 3.1;
		target.napping = false;
		target.boredom = 0;
		target.partner = "director";
		stress = clamp(stress + 22, 0, 100);
		quality = clamp(quality - 8, 0, 100);
		shake = Math.max(shake, 1);
		say(target, ISSUES[target.id], "angry");
		say(byId("director"), `¡${target.name}, resolvé eso! No podemos seguir así.`, "dir");
	}
	function corten() {
		paused = true;
		cancelChat();
		stress = clamp(stress - 30, 0, 100);
		for (const p of people) {
			p.boredom = 0;
			p.napping = false;
			p.partner = null;
			if (p.state === "sleep" || p.state === "angry" || p.state === "talk") release(p);
			else {
				p.tx = p.homeX;
				p.ty = p.homeY;
			}
		}
		say(byId("director"), "¡Corten! Pausa de cinco minutos. Respiramos y volvemos.", "dir");
	}
	function focus(id) {
		const p = byId(id);
		click(p.x, p.y - .06);
	}
	function click(nx, ny) {
		let best = null;
		let bestD = .09;
		for (const p of people) {
			const d = dist(nx, ny, p.x, p.y - .06);
			if (d < bestD) {
				best = p;
				bestD = d;
			}
		}
		if (!best) return;
		best.ring = 2.2;
		if (best.state === "sleep") say(best, "Shh… cinco minutos y vuelvo.", "ok");
		else if (best.state === "angry") say(best, "Ya lo estoy arreglando. No me apuren.", "angry");
		else if (best.state === "talk") say(best, "Estoy en esto con el equipo.", "ok");
		else say(best, best.job, best.id === "director" ? "dir" : "ok");
	}
	function hud() {
		return {
			take,
			scene: SCENES[sceneIndex] ?? SCENES[0],
			stress: Math.round(stress),
			quality: Math.round(quality),
			mood: moodText(),
			paused,
			people: people.map((p) => ({
				id: p.id,
				name: p.name,
				role: p.role,
				state: p.state,
				moving: p.state === "work" && dist(p.x, p.y, p.tx, p.ty) > .02
			}))
		};
	}
	return {
		people,
		particles,
		step,
		accion,
		scold: scoldRandom,
		chaos,
		corten,
		click,
		focus,
		hud,
		get shake() {
			return shake;
		}
	};
}
var POSES = [
	"pose-1",
	"pose-2",
	"pose-3",
	"pose-4"
];
var INITIAL_LOG = [
	{
		id: -3,
		who: "Rey",
		text: "Bienvenidos al set. Hoy la emoción tiene que aguantar la estructura.",
		kind: "dir"
	},
	{
		id: -2,
		who: "Sol",
		text: "Tengo el conflicto. Falta decidir qué sabe el espectador.",
		kind: "ok"
	},
	{
		id: -1,
		who: "Lila",
		text: "Cuando haya material, reviso ritmo, elipsis y continuidad.",
		kind: "ok"
	}
];
var INITIAL_HUD = {
	take: 1,
	scene: "La traición",
	stress: 12,
	quality: 8,
	mood: "Rodando. Los departamentos trabajan.",
	paused: false,
	people: CREW.map((c) => ({
		id: c.id,
		name: c.name,
		role: c.role,
		state: "work",
		moving: false
	}))
};
function assetUrl(path) {
	if (typeof window === "undefined") return path;
	return `${previewPathPrefix(window.location.hostname, window.location.pathname) ?? ""}${path}`;
}
function wrap(ctx, text, max) {
	const words = text.split(" ");
	const lines = [];
	let cur = "";
	for (const word of words) {
		const next = cur ? `${cur} ${word}` : word;
		if (ctx.measureText(next).width > max && cur) {
			lines.push(cur);
			cur = word;
		} else cur = next;
	}
	if (cur) lines.push(cur);
	return lines.slice(0, 4);
}
function poseFor(p, moving, t) {
	if (p.state === "sleep") return "pose-4";
	if (p.state === "angry") return "pose-3";
	const step = Math.floor(t * (moving ? 8 : 2) + p.homeX * 10) % 2;
	if (moving) return step === 0 ? "pose-2" : "pose-1";
	return step === 0 ? "pose-1" : "pose-2";
}
function FilmSet() {
	const canvasRef = (0, import_react.useRef)(null);
	const simRef = (0, import_react.useRef)(null);
	const [hud, setHud] = (0, import_react.useState)(INITIAL_HUD);
	const [log, setLog] = (0, import_react.useState)(INITIAL_LOG);
	const [ready, setReady] = (0, import_react.useState)(false);
	const logRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let audio = null;
		const unlock = () => {
			if (!audio) audio = new AudioContext();
			if (audio.state === "suspended") audio.resume();
		};
		const blip = (kind) => {
			if (!audio || audio.state !== "running") return;
			const osc = audio.createOscillator();
			const gain = audio.createGain();
			osc.type = "square";
			osc.frequency.value = kind === "angry" ? 170 : kind === "dir" ? 310 : 460;
			gain.gain.value = .028;
			osc.connect(gain);
			gain.connect(audio.destination);
			osc.start();
			const stopAt = audio.currentTime + .07;
			gain.gain.exponentialRampToValueAtTime(1e-4, stopAt);
			osc.stop(stopAt);
		};
		const sim = createSim((line) => {
			blip(line.kind);
			setLog((prev) => [line, ...prev].slice(0, 40));
		});
		simRef.current = sim;
		const director = sim.people.find((p) => p.id === "director");
		if (director) director.bubble = {
			text: "Bienvenidos al set. Hoy la emoción tiene que aguantar la estructura.",
			life: 4.6,
			kind: "dir"
		};
		const sprites = /* @__PURE__ */ new Map();
		const stage = new Image();
		let stageOk = false;
		let loaded = 0;
		const needed = CREW.length * POSES.length;
		const mark = () => {
			loaded += 1;
			if (loaded >= needed && stageOk) setReady(true);
		};
		stage.onload = () => {
			stageOk = true;
			if (loaded >= needed) setReady(true);
		};
		stage.src = assetUrl("/set/stage.jpg");
		for (const crew of CREW) for (const pose of POSES) {
			const img = new Image();
			img.onload = () => {
				sprites.set(`${crew.id}:${pose}`, img);
				mark();
			};
			img.onerror = () => mark();
			img.src = assetUrl(`/sprites/${crew.id}/${pose}.png`);
		}
		let raf = 0;
		let last = performance.now();
		let acc = 0;
		let anim = 0;
		let hudTick = 0;
		const layout = {
			ox: 0,
			oy: 0,
			dw: 1,
			dh: 1
		};
		const draw = () => {
			const rect = canvas.getBoundingClientRect();
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			const w = Math.max(1, Math.round(rect.width * dpr));
			const h = Math.max(1, Math.round(rect.height * dpr));
			if (canvas.width !== w || canvas.height !== h) {
				canvas.width = w;
				canvas.height = h;
			}
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.imageSmoothingEnabled = false;
			const cw = rect.width;
			const ch = rect.height;
			ctx.fillStyle = "#12100e";
			ctx.fillRect(0, 0, cw, ch);
			const shake = sim.shake;
			const sx = shake ? (Math.random() - .5) * shake * 10 : 0;
			const sy = shake ? (Math.random() - .5) * shake * 6 : 0;
			ctx.save();
			ctx.translate(sx, sy);
			if (stageOk && stage.naturalWidth) {
				const scale = Math.min(cw / stage.naturalWidth, ch / stage.naturalHeight);
				layout.dw = stage.naturalWidth * scale;
				layout.dh = stage.naturalHeight * scale;
				layout.ox = (cw - layout.dw) / 2;
				layout.oy = (ch - layout.dh) / 2;
				ctx.drawImage(stage, layout.ox, layout.oy, layout.dw, layout.dh);
			} else {
				layout.ox = 0;
				layout.oy = 0;
				layout.dw = cw;
				layout.dh = ch;
			}
			const toX = (nx) => layout.ox + nx * layout.dw;
			const toY = (ny) => layout.oy + ny * layout.dh;
			const size = layout.dh * .23;
			const ordered = [...sim.people].sort((a, b) => a.y - b.y);
			for (const p of ordered) {
				const x = toX(p.x);
				const y = toY(p.y);
				const moving = p.state === "work" && Math.hypot(p.tx - p.x, p.ty - p.y) > .015;
				const bob = p.state === "sleep" ? 0 : Math.sin(anim * (p.state === "angry" ? 22 : 3) + p.homeX * 12) * (p.state === "angry" ? 1.4 : 1.1);
				ctx.fillStyle = "rgba(0,0,0,0.28)";
				ctx.beginPath();
				ctx.ellipse(x, y, size * .22, size * .08, 0, 0, Math.PI * 2);
				ctx.fill();
				if (p.ring > 0) {
					ctx.strokeStyle = "#e2b340";
					ctx.lineWidth = 2;
					ctx.beginPath();
					ctx.ellipse(x, y, size * .28, size * .1, 0, 0, Math.PI * 2);
					ctx.stroke();
				}
				const frame = sprites.get(`${p.id}:${poseFor(p, moving, anim)}`);
				if (frame) {
					ctx.save();
					ctx.translate(x, y + bob);
					ctx.scale(p.facing, 1);
					ctx.drawImage(frame, -size / 2, -size, size, size);
					ctx.restore();
				}
				if (p.state === "angry") {
					ctx.strokeStyle = "#d4533c";
					ctx.lineWidth = 2;
					ctx.beginPath();
					ctx.moveTo(x - 16, y - size + 6);
					ctx.lineTo(x - 8, y - size + 12);
					ctx.moveTo(x + 16, y - size + 6);
					ctx.lineTo(x + 8, y - size + 12);
					ctx.stroke();
				}
				ctx.font = "600 11px 'Source Sans 3', sans-serif";
				ctx.textAlign = "center";
				ctx.textBaseline = "top";
				const label = p.name;
				const lw = ctx.measureText(label).width + 10;
				ctx.fillStyle = "rgba(18,16,14,0.78)";
				ctx.fillRect(x - lw / 2, y + 4, lw, 15);
				ctx.fillStyle = p.state === "angry" ? "#d4533c" : p.state === "sleep" ? "#b3a48f" : "#f4ecdf";
				ctx.fillText(label, x, y + 6);
			}
			for (const particle of sim.particles) {
				const x = toX(particle.x);
				const y = toY(particle.y);
				const alpha = Math.max(0, particle.life / particle.max);
				ctx.globalAlpha = alpha;
				if (particle.kind === "z") {
					ctx.fillStyle = "#f4ecdf";
					ctx.font = "700 13px 'Source Sans 3', sans-serif";
					ctx.textAlign = "center";
					ctx.fillText(particle.char, x, y);
				} else if (particle.kind === "steam") {
					ctx.fillStyle = "#d4533c";
					ctx.fillRect(x, y, 3, 3);
				} else {
					ctx.fillStyle = "#e2b340";
					ctx.fillRect(x, y, 4, 3);
				}
				ctx.globalAlpha = 1;
			}
			ctx.font = "600 12px 'Source Sans 3', sans-serif";
			for (const p of sim.people) {
				if (!p.bubble) continue;
				const lines = wrap(ctx, p.bubble.text, 168);
				const bw = Math.min(190, Math.max(...lines.map((line) => ctx.measureText(line).width)) + 16);
				const bh = lines.length * 15 + 10;
				let bx = toX(p.x) - bw / 2;
				let by = toY(p.y) - size - bh - 6;
				bx = Math.max(layout.ox + 4, Math.min(bx, layout.ox + layout.dw - bw - 4));
				if (by < layout.oy + 4) by = toY(p.y) + 22;
				ctx.fillStyle = p.bubble.kind === "angry" ? "#3a1814" : p.bubble.kind === "dir" ? "#2c2414" : "#1c1814";
				ctx.strokeStyle = p.bubble.kind === "angry" ? "#d4533c" : p.bubble.kind === "dir" ? "#e2b340" : "#6a5c48";
				ctx.lineWidth = 2;
				ctx.fillRect(bx, by, bw, bh);
				ctx.strokeRect(bx, by, bw, bh);
				ctx.fillStyle = p.bubble.kind === "angry" ? "#ffd0c6" : "#f4ecdf";
				ctx.textAlign = "left";
				ctx.textBaseline = "top";
				lines.forEach((line, i) => ctx.fillText(line, bx + 8, by + 6 + i * 15));
			}
			ctx.restore();
		};
		const frame = (now) => {
			let dt = (now - last) / 1e3;
			last = now;
			if (dt > .1) dt = .1;
			acc += dt;
			anim += dt;
			while (acc >= 1 / 60) {
				sim.step(1 / 60);
				acc -= 1 / 60;
			}
			draw();
			hudTick += dt;
			if (hudTick > .25) {
				hudTick = 0;
				setHud(sim.hud());
			}
			raf = requestAnimationFrame(frame);
		};
		raf = requestAnimationFrame(frame);
		const onPointer = (event) => {
			unlock();
			const rect = canvas.getBoundingClientRect();
			const x = event.clientX - rect.left;
			const y = event.clientY - rect.top;
			const nx = (x - layout.ox) / layout.dw;
			const ny = (y - layout.oy) / layout.dh;
			sim.click(nx, ny);
		};
		canvas.addEventListener("pointerdown", onPointer);
		window.addEventListener("pointerdown", unlock);
		return () => {
			cancelAnimationFrame(raf);
			canvas.removeEventListener("pointerdown", onPointer);
			window.removeEventListener("pointerdown", unlock);
			simRef.current = null;
		};
	}, []);
	const run = (fn) => {
		const sim = simRef.current;
		if (!sim) return;
		fn(sim);
		setHud(sim.hud());
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-5xl flex-col gap-3 px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.22em] text-primary",
						children: "SET DE RODAJE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl leading-none text-fg",
						children: "Pixel Set"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Trabajan, discuten, se enojan y vuelven a la toma."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xs text-sm text-fg",
					children: hud.mood
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative aspect-video w-full overflow-hidden rounded-md border border-border bg-bg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: canvasRef,
					className: "h-full w-full touch-none",
					"aria-label": "Set de filmación con el equipo trabajando"
				}), !ready && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pointer-events-none absolute inset-0 grid place-items-center text-sm text-muted",
					children: "Preparando el set…"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				"aria-label": "Estado de la toma",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-border bg-surface px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: ["Toma ", hud.take]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg text-fg",
							children: hud.scene
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Escena",
						value: hud.quality,
						tone: "primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Estrés",
						value: hud.stress,
						tone: "danger"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				"aria-label": "Departamentos",
				children: hud.people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => run((sim) => sim.focus(p.id)),
					className: "min-h-11 shrink-0 rounded-md border border-border bg-surface px-3 py-1.5 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-semibold text-fg",
						children: p.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: `block text-xs ${p.state === "angry" ? "text-danger" : p.state === "sleep" ? "text-muted" : "text-primary"}`,
						children: [
							p.role,
							" · ",
							stateLabel(p.state, p.moving)
						]
					})]
				}, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => run((sim) => sim.accion()),
						className: "inline-flex min-h-11 items-center justify-center gap-2 rounded-md border border-primary bg-primary px-3 text-sm font-semibold text-bg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, {
							className: "size-4",
							"aria-hidden": "true"
						}), "¡Acción!"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => run((sim) => sim.scold()),
						className: btn,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Rey reta"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => run((sim) => sim.chaos()),
						className: btn,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Problema"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => run((sim) => sim.corten()),
						className: btn,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
							className: "size-4",
							"aria-hidden": "true"
						}), "¡Corten!"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: logRef,
				className: "h-36 overflow-y-auto rounded-md border border-border bg-surface p-3 text-sm leading-relaxed",
				"aria-live": "polite",
				children: log.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: line.kind === "angry" ? "font-semibold text-danger" : line.kind === "dir" ? "font-semibold text-primary" : "font-semibold text-fg",
							children: [line.who, ":"]
						}),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: line.text
						})
					]
				}, line.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Tocá a alguien en el set para escucharlo. Si se duermen, Rey los levanta."
			})
		]
	});
}
var btn = "inline-flex min-h-11 items-center justify-center gap-2 rounded-md border border-border bg-surface px-3 text-sm font-semibold text-fg hover:border-primary hover:text-primary";
function Meter({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-border bg-surface px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-1 flex items-center justify-between text-xs text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-fg",
				children: [value, "%"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-2 overflow-hidden rounded-full bg-bg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: tone === "danger" ? "h-full bg-danger" : "h-full bg-primary",
				style: { width: `${value}%` }
			})
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilmSet, {});
}
//#endregion
export { Home as component };
